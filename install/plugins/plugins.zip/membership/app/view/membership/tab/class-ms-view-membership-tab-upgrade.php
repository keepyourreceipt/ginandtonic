<?php
/**
 * Tab: Edit Upgrade Paths
 *
 * Extends MS_View for rendering methods and magic methods.
 *
 * @since  1.0.0
 * @package Membership2
 * @subpackage View
 */
class MS_View_Membership_Tab_Upgrade extends MS_View {

	// PRO FEATURE

};